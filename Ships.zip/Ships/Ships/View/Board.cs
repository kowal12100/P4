﻿using Ships.Controler;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Ships
{
    public partial class Board : Form 
    {
        
        public Board()
        {
            InitializeComponent();
            var _controller = new ButtonBoard();
            _controller.Draw(this);
        }

        private void button106_Click(object sender, EventArgs e)
        {
            string a = "Wybierz jaki rodzaj statku chcesz postawić. \n Zaznacz na planszy gdzie chcesz swój statek. \n Kiedy skończysz kliknij przycisk dalej.\n";
            MessageBox.Show(a);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Menu a = new Menu();
            a.Show();
            this.Hide();
        }

        private void Board_Load(object sender, EventArgs e)
        {

        }
    }

}
