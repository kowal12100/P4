﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ships.Controler
{
    public class ButtonBoard
    {
        public bool Draw(Form board)
        {
            var errors = false;

            try
            {
                var _boardX = 40;
                var _boardY = 80;

                for (int x = 0; x < 10; x++)
                {
                    for (int y = 0; y < 10; y++)
                    {
                        var temp = new Button()
                        {
                            Height = 40,
                            Width = 40,
                            Location = new Point(_boardX, _boardY),
                        };
                    
                        board.Controls.Add(temp);

                        _boardY += 40;
                    }
                    _boardY = 80;
                    _boardX += 40;
                }

            }
            catch (Exception e)
            {
                errors = true;
            }

            return errors;
        }
        }
}

